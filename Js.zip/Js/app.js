// Supabase configuration
const SUPABASE_URL = 'https://jmaxlblmncctabomgfqw.supabase.co';
const SUPABASE_ANON_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImptYXhsYmxtbmNjdGFib21nZnF3Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjExMjU1MjksImV4cCI6MjA3NjcwMTUyOX0.faBQy2IyUPv8MNsDjyqs_uhVQIPlCZaVmdJP8jKD-AA';

// Initialize Supabase client
const { createClient } = supabase;
const supabaseClient = createClient(SUPABASE_URL, SUPABASE_ANON_KEY);

// Quiz questions
const questions = [
    {
        question: "How would you describe your overall mood today?",
        options: [
            { text: "Great! I'm feeling very positive", value: 5 },
            { text: "Pretty good, generally happy", value: 4 },
            { text: "Okay, just average", value: 3 },
            { text: "Not great, feeling a bit down", value: 2 },
            { text: "Very difficult, really struggling", value: 1 }
        ]
    },
    {
        question: "How well have you been sleeping recently?",
        options: [
            { text: "Very well, getting quality rest", value: 5 },
            { text: "Pretty well, mostly satisfied", value: 4 },
            { text: "Okay, could be better", value: 3 },
            { text: "Not well, having some difficulties", value: 2 },
            { text: "Very poorly, serious sleep issues", value: 1 }
        ]
    },
    {
        question: "How are your stress levels?",
        options: [
            { text: "Very low, feeling calm and relaxed", value: 5 },
            { text: "Manageable, nothing too overwhelming", value: 4 },
            { text: "Moderate, some stressful moments", value: 3 },
            { text: "High, feeling quite stressed", value: 2 },
            { text: "Extremely high, feeling overwhelmed", value: 1 }
        ]
    },
    {
        question: "How connected do you feel to others?",
        options: [
            { text: "Very connected, strong relationships", value: 5 },
            { text: "Connected, good support system", value: 4 },
            { text: "Somewhat connected, could be better", value: 3 },
            { text: "Isolated, lacking connections", value: 2 },
            { text: "Very isolated, feeling alone", value: 1 }
        ]
    },
    {
        question: "How motivated are you to do daily activities?",
        options: [
            { text: "Very motivated, full of energy", value: 5 },
            { text: "Motivated, getting things done", value: 4 },
            { text: "Somewhat motivated, doing what's needed", value: 3 },
            { text: "Low motivation, struggling to start tasks", value: 2 },
            { text: "No motivation, very difficult to do anything", value: 1 }
        ]
    }
];

let currentQuestion = 0;
let answers = [];
let answerTexts = [];
let totalScore = 0;

// Start the quiz
function startQuiz() {
    document.getElementById('startScreen').classList.remove('active');
    document.getElementById('quizScreen').classList.add('active');
    currentQuestion = 0;
    answers = [];
    answerTexts = [];
    totalScore = 0;
    showQuestion();
}

// Display current question
function showQuestion() {
    const question = questions[currentQuestion];
    document.getElementById('question').textContent = question.question;
    document.getElementById('questionCounter').textContent = `Question ${currentQuestion + 1} of ${questions.length}`;
    
    const optionsContainer = document.getElementById('options');
    optionsContainer.innerHTML = '';
    
    question.options.forEach((option, index) => {
        const optionDiv = document.createElement('div');
        optionDiv.className = 'option';
        optionDiv.textContent = option.text;
        optionDiv.onclick = () => selectOption(index, option.value, option.text);
        optionsContainer.appendChild(optionDiv);
    });
    
    document.getElementById('nextBtn').style.display = 'none';
    updateProgressBar();
}

// Handle option selection
function selectOption(index, value, text) {
    // Remove previous selection
    document.querySelectorAll('.option').forEach(opt => {
        opt.classList.remove('selected');
    });
    
    // Add selection to clicked option
    document.querySelectorAll('.option')[index].classList.add('selected');
    
    // Store answer value and text
    answers[currentQuestion] = value;
    answerTexts[currentQuestion] = text;
    
    // Show next button
    document.getElementById('nextBtn').style.display = 'block';
}

// Move to next question
function nextQuestion() {
    if (answers[currentQuestion] === undefined) {
        alert('Please select an option');
        return;
    }
    
    currentQuestion++;
    
    if (currentQuestion < questions.length) {
        showQuestion();
    } else {
        showResults();
    }
}

// Update progress bar
function updateProgressBar() {
    const progress = ((currentQuestion + 1) / questions.length) * 100;
    document.getElementById('progressBar').style.width = progress + '%';
}

// Calculate and show results
async function showResults() {
    totalScore = answers.reduce((sum, answer) => sum + answer, 0);
    const maxScore = 25;
    const percentage = (totalScore / maxScore) * 100;
    
    let resultCategory, resultIcon, resultTitle, resultMessage, needsSupport;
    
    if (percentage >= 80) {
        resultCategory = "Excellent Mental Health";
        resultIcon = "🌟";
        resultTitle = "You're Doing Great!";
        resultMessage = "Your responses indicate that you're in a very positive mental state. Keep up the good work with your self-care routines!";
        needsSupport = false;
    } else if (percentage >= 60) {
        resultCategory = "Good Mental Health";
        resultIcon = "😊";
        resultTitle = "You're Doing Well!";
        resultMessage = "You're generally doing well, though there might be some areas where you could use a little support or attention.";
        needsSupport = false;
    } else if (percentage >= 40) {
        resultCategory = "Moderate Concerns";
        resultIcon = "😐";
        resultTitle = "Some Challenges Detected";
        resultMessage = "It seems like you're facing some challenges. Consider reaching out to friends, family, or a mental health professional for support.";
        needsSupport = true;
    } else if (percentage >= 20) {
        resultCategory = "Significant Concerns";
        resultIcon = "😟";
        resultTitle = "We're Here for You";
        resultMessage = "You're going through a difficult time. Please consider talking to a mental health professional. Remember, seeking help is a sign of strength.";
        needsSupport = true;
    } else {
        resultCategory = "Urgent Concerns";
        resultIcon = "😢";
        resultTitle = "Please Seek Support";
        resultMessage = "Your responses indicate you're struggling significantly. Please reach out to a mental health professional or crisis helpline immediately. You don't have to face this alone.";
        needsSupport = true;
    }
    
    // Save to database if user is logged in
    const user = JSON.parse(sessionStorage.getItem('user') || 'null');
    if (user) {
        try {
            const { data, error } = await supabaseClient
                .from('quiz_responses')
                .insert([{
                    user_id: user.user_id,
                    total_score: totalScore,
                    result_category: resultCategory,
                    needs_support: needsSupport,
                    
                    // Question 1
                    question_1_text: questions[0].question,
                    question_1_answer: answers[0] || null,
                    question_1_answer_text: answerTexts[0] || null,
                    
                    // Question 2
                    question_2_text: questions[1].question,
                    question_2_answer: answers[1] || null,
                    question_2_answer_text: answerTexts[1] || null,
                    
                    // Question 3
                    question_3_text: questions[2].question,
                    question_3_answer: answers[2] || null,
                    question_3_answer_text: answerTexts[2] || null,
                    
                    // Question 4
                    question_4_text: questions[3].question,
                    question_4_answer: answers[3] || null,
                    question_4_answer_text: answerTexts[3] || null,
                    
                    // Question 5
                    question_5_text: questions[4].question,
                    question_5_answer: answers[4] || null,
                    question_5_answer_text: answerTexts[4] || null
                }]);
            
            if (error) {
                console.error('Error saving quiz response:', error);
            } else {
                console.log('Quiz response saved successfully!');
            }
        } catch (error) {
            console.error('Error saving quiz response:', error);
        }
    }
    
    // Display results
    document.getElementById('quizScreen').classList.remove('active');
    document.getElementById('resultsScreen').classList.add('active');
    
    document.getElementById('resultIcon').textContent = resultIcon;
    document.getElementById('resultTitle').textContent = resultTitle;
    document.getElementById('resultMessage').textContent = resultMessage;
    
    // Add support resources if needed
    if (needsSupport) {
        document.getElementById('supportSection').innerHTML = `
            <div class="support-resources">
                <h3>📞 Support Resources</h3>
                <ul>
                    <li><strong>National Crisis Helpline:</strong> 988 (24/7)</li>
                    <li><strong>Crisis Text Line:</strong> Text HOME to 741741</li>
                    <li><strong>International Association for Suicide Prevention:</strong> <a href="https://www.iasp.info/resources/Crisis_Centres/" target="_blank">Find local helplines</a></li>
                </ul>
            </div>
        `;
    } else {
        document.getElementById('supportSection').innerHTML = '';
    }
    
    // Add encouragement
    document.getElementById('encouragementSection').innerHTML = `
        <div class="encouragement">
            <h3>💙 Remember</h3>
            <p>Mental health is a journey, not a destination. Be kind to yourself, and remember that it's okay to ask for help when you need it.</p>
        </div>
    `;
    
    updateProgressBar();
}

// Restart the quiz
function restartQuiz() {
    document.getElementById('resultsScreen').classList.remove('active');
    document.getElementById('startScreen').classList.add('active');
    currentQuestion = 0;
    answers = [];
    answerTexts = [];
    totalScore = 0;
    document.getElementById('progressBar').style.width = '0%';
}